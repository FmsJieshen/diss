import Vue from 'vue'
import Router from 'vue-router'
import  Reacommend from '../components/recommend/recommend'
import  Singer from '../components/singer/singer'
import  Rank from '../components/rank/rank'
import  Search from '../components/search/search'

Vue.use(Router)

const SingerDetail = (resolve) => {
  import('../components/singer-detail/singer-detail').then((module) => {
    resolve(module)
  })
}

export default new Router({
  routes: [
    {
     path:'/',
     component:Reacommend
    },
    {
      path:'/recommend',
      component:Reacommend
    },
    {
      path: '/singer',
      component: Singer,
      children: [
        {
          path: ':id',
          component: SingerDetail
        }
      ]
    },
    {
      path:'/rank',
      component:Rank
    },
    {
      path:'/search',
      component:Search
    },
  ]
})
const originalPush = Router.prototype.push
Router.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}
