<template>
    <div>
      推荐页面
    </div>
</template>

<script>
    export default {
        name: "search"
    }
</script>

<style scoped>

</style>
