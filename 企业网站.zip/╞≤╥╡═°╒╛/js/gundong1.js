//gundong
var speed = 30;
var colee_left2 = document.getElementById("colee_left2");
var colee_left1 = document.getElementById("colee_left1");
var colee_left_1 = document.getElementById("colee_left_1");
colee_left2.innerHTML = colee_left1.innerHTML
function Marquee3() {
  if (colee_left2.offsetWidth-colee_left_1.scrollLeft<=0)
    colee_left_1.scrollLeft-=colee_left1.offsetWidth
  else {
    colee_left_1.scrollLeft++
  }
}
var MyMar3 = setInterval(Marquee3,speed)
colee_left_1.onmouseover=function () {
  clearInterval(MyMar3)
}
colee_left_1.onmouseout=function () {
  MyMar3=setInterval(Marquee3,speed)
}
