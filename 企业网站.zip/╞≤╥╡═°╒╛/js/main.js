function showobj(id) {
  var obj = document.getElementById("nav1");
  obj.style.display = "inline-table";
}
function hiddenobj(id) {
  var obj = document.getElementById("nav1");
  obj.style.display = "none";
}
//setInterval(runname,1000)
var arr = new Array;
arr[0] = "./images/banner1.jpg";
arr[1] = "./images/banner2.jpg";
arr[2] = "./images/banner3.jpg";
arr[3] = "./images/banner4.jpg";
var count = 0;
function autoPlayer() {
  if (arr.length == count)
  count=0;
  document.getElementById("banner1").src=arr[count];
  count++;
}

var Timer = setInterval(autoPlayer,2000);

function clearTimer() {
  clearInterval(Timer);
}

function showbannerbyid(num) {
  clearTimer();
  var index = parseInt(num);
  document.getElementById("banner1").src=arr[index - 1];
  count = index;
}
//leave
function btnHouseout() {
  Timer = setInterval(autoPlayer,2000);
}
function changehight() {
  var QQ = document.getElementById("zixunbox");
  QQ.style.top = document.documentElement.scrollTop+document.body.scrollTop+200+"px";
}

window.onscroll = changehight;

//验证
function isok() {
    if (document.getElementById("username").value=="" ||document.getElementById("username").value==NaN) {
      alert("用户名不能为空");
      return false;
    }
    if (document.getElementById("email").value=="" ||document.getElementById("email").value==NaN) {
      alert("Email不能为空");
      return false;
    }
    if (document.getElementById("QQ").value=="" ||document.getElementById("QQ").value==NaN) {
      alert("QQ不能为空");
      return false;
    }
    if (document.getElementById("Mobile").value=="" ||document.getElementById("Mobile").value==NaN) {
      alert("电话不能为空");
      return false;
    }
    if (document.getElementById("content").value=="" ||document.getElementById("content").value==NaN) {
      alert("内容不能为空");
      return false;
    }
    var email= /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((\.[a-zA-Z0-9_-]{2,3}){1,2})$/;

    if (!document.getElementById("email").value.match(email)){
      alert("Email格式错误");

      return false;
    }
    var QQ= /^[0-9]*[1-9][0-9]*$/;
    if (!document.getElementById("QQ").value.match(QQ)){
      alert("QQ格式错误");

      return false;
    }
    var Mobile= /^(\(\d{3,4}\)|\d{3,4}-|\s)?\d{7,14}/;
    if (!document.getElementById("Mobile").value.match(Mobile)){
      alert("手机号码格式错误");

      return false;
    }
    if (document.getElementById("content").value.length>50){
      alert("不能超过50个字符");

      return false;
    }
     return true;
}
