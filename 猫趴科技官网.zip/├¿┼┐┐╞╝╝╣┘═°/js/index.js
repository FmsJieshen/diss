$(function() {
  /* owl carousel */
  var owl = $('.owl-carousel');
  owl.owlCarousel({
    margin: 10,
    nav: true,
    loop: true,
    responsive: {
      0: {
        items: 1
      }
    }
  })
  /* //owl carousel */


//首页检查是否过低IE版本
  function myBrowser(){
    var userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
    var isOpera = userAgent.indexOf("Opera") > -1; //判断是否Opera浏览器
    var isIE = userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1 && !isOpera; //判断是否IE浏览器
    var isFF = userAgent.indexOf("Firefox") > -1; //判断是否Firefox浏览器
    var isSafari = userAgent.indexOf("Safari") > -1; //判断是否Safari浏览器
    if (isIE) {
      var IE5 = IE55 = IE6 = IE7 = IE8 = false;
      var reIE = new RegExp("MSIE (\\d+\\.\\d+);");
      reIE.test(userAgent);
      var fIEVersion = parseFloat(RegExp["$1"]);
      IE55 = fIEVersion == 5.5;
      IE6 = fIEVersion == 6.0;
      IE7 = fIEVersion == 7.0;
      IE8 = fIEVersion == 8.0;
      IE9 = fIEVersion == 9.0;
      if (IE55 || IE6 || IE7 || IE8 || IE9) {
        return false;
      }
      return true;
    }else{
      return true;
    }
  }

  if(!myBrowser()){  //浏览器版本小于10就弹出更新浏览器提示
    $("#overMask").addClass("ietips").show();
    $("#jqIE_tips").show();
  }

  $('#index_blocks').fullpage({
    verticalCentered: false,
    fitToSectionDelay: 300,
    resize: true,
    afterLoad:function(anchorLink,index){
      if(index == 2){  //当滚到第二屏时
        $(".benefit_list>li").addClass("on");

        var timemout = setTimeout(function(){
          $("#xcx_img").addClass("on");
        },1200);


      }else{
        $(".benefit_list>li").removeClass("on");
        // $("#xcx_img").fadeOut();
        $("#xcx_img").removeClass("on");
        clearTimeout(timemout);
      }

      if(index ==5){
        /* stats-counter */
        $('.counter').countUp();
        /* /stats-counter */
      }
    }
  });

  $(".header_btn").click(function(){
    let index = $(".header_btn").index(this)+1;
    $.fn.fullpage.moveTo(index);
  })

  var mySwiper = new Swiper('.swiper-container',{
    pagination: '.pagination',
    loop:true,
    grabCursor: true,
    paginationClickable: true,
    autoplay: 3000,
    autoplayDisableOnInteraction : false
  });




});
