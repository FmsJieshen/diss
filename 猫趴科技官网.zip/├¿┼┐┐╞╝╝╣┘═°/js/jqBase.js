//web目录下所有文件的根目录为pages，故默认要上翻一级
var base = ((window.base || "/pitaya")+"/").replace(/[\\/]\//,'/');

/**自动跳转到https链接*/
if(/http:\/\/(www\.)?wmzx.com/i.test(location.href)){
  location.href = "https://www.wmzx.com/"+(location.href.substring(location.href.indexOf("wmzx.com")+9));
}


/***
 * 用于百度统计
 */
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?d97aa50e591a47625faeb9c7dacfea27";
  var s = document.getElementsByTagName("script")[0];
  s.parentNode.insertBefore(hm, s);
})();



//使用jQuery扩展方法来创建全局方法
(function($){
  $.extend({
    jqNormalTimeString : function(timestamp){
      var d = new Date(timestamp);
      var year = d.getFullYear();
      var _month = d.getMonth()+1;
      var month = _month<=9?"0"+_month:_month;
      var day = (d.getDate()<=9)?"0"+d.getDate():d.getDate();
      var hour = (d.getHours()<=9)?"0"+d.getHours():d.getHours();
      var minute = (d.getMinutes()<=9)?"0"+d.getMinutes():d.getMinutes();
      var second = (d.getSeconds()<=9)?"0"+d.getSeconds():d.getSeconds();

      var jqTime = year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second;
      return jqTime;
    },
    jqDate : function(timestamp){
      var d = new Date(timestamp);
      var year = d.getFullYear();
      var _month = d.getMonth()+1;
      var month = _month<=9?"0"+_month:_month;
      var day = (d.getDate()<=9)?"0"+d.getDate():d.getDate();

      var jqTime = year + "-" + month + "-" + day;
      return jqTime;
    },
    jqLessonTimeString : function(startTime,endTime){
      var d = new Date(startTime);
      var year = d.getFullYear();
      var _month = d.getMonth()+1;
      var month = _month<=9?"0"+_month:_month;
      var day = (d.getDate()<=9)?"0"+d.getDate():d.getDate();
      var hour = (d.getHours()<=9)?"0"+d.getHours():d.getHours();
      var minute = (d.getMinutes()<=9)?"0"+d.getMinutes():d.getMinutes();

      var d2 = new Date(endTime);
      var hour2 = (d2.getHours()<=9)?"0"+d2.getHours():d2.getHours();
      var minute2 = (d2.getMinutes()<=9)?"0"+d2.getMinutes():d2.getMinutes();

      var jqTime = year + "-" + month + "-" + day + " " + hour + ":" + minute + "-" + hour2 + ":" + minute2;
      return jqTime;
    },
    jqGetRequest : function(){
      var url = location.search; //获取url中"?"符后的字串
      var theRequest = new Object();
      if (url.indexOf("?") != -1) {
        var str = url.substr(1);
        strs = str.split("&");
        for(var i = 0; i < strs.length; i ++) {
          theRequest[strs[i].split("=")[0]]=(strs[i].split("=")[1]);
        }
      }
      return theRequest;
    },
    jqGetCookie:function(cookieName){ //获取cookie
      var cookieString = document.cookie;
      var start = cookieString.indexOf(cookieName + '=');
      // 加上等号的原因是避免在某些 Cookie 的值里有
      // 与 cookieName 一样的字符串。
      if (start == -1) // 找不到
        return null;
      start += cookieName.length + 1;
      var end = cookieString.indexOf(';', start);  //若end不等于-1则表示后面还有cookie
      if (end == -1) return unescape(cookieString.substring(start));
      return unescape(cookieString.substring(start, end));
    },
    jqDelCookie:function(cookieName){  //删除cookie
      document.cookie = cookieName+"=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/";
    },
    getDomain:function(){
      var _href = location.href;
      var index = _href.indexOf(".com");
      return _href.substring(0,index+4);
    }
  });
})(jQuery);
